package com.ourbusway.uaa.resource.auth;

import lombok.Data;

@Data
public class RefreshTokenPostResource {
    private String refreshToken;
}
