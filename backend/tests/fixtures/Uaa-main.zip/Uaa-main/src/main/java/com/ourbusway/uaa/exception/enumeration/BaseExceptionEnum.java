package com.ourbusway.uaa.exception.enumeration;

public interface BaseExceptionEnum {
    String getCode();
}
