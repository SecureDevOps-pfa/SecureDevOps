package com.ourbusway.uaa.service;


public interface DataLoaderService {

    void createAdminUser();

    void createDefaultPassenger();

    void createDefaultDriver();

    void createDefaultController();
}
