package com.ourbusway.uaa.service;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface LocalUserDetailsService extends UserDetailsService {
}
