package com.ourbusway.uaa.resource.auth;

import lombok.Data;

@Data
public class TokenValidationPostResource {
    private String token;
}
