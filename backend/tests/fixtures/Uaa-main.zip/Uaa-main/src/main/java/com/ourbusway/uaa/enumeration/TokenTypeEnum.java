package com.ourbusway.uaa.enumeration;

public enum TokenTypeEnum {
    ACCOUNT_VALIDATION,
    PASSWORD_RESET,
    API_KEY
}
