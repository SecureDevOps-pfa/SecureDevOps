package com.ourbusway.uaa.resource.auth;

import lombok.Data;

@Data
public class UserForgotPasswordPostResource {
    private String email;
}
