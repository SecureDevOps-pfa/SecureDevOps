package com.math_lab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MathLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
